- Close the software after complete installation.


- Then copy the ja-netfilter folder to the C drive.


- Then enter the folder you copied in drive C and enter the scripts folder.
  Run the install-all-users file.
  You will encounter a message that tells you that the execution of this file may take a few moments.
  Click the ok button and wait until you get the second message (Done), which is the execution confirmation message.

- Done...

Enjoy
=================
www.microcharon.com | Provided by Downloadly